'use strict';

// Audio Source
var audioData = [
    {
        'title' : 'Love and Civilization',
        'url' : 'https://s3.amazonaws.com/dsimon-alexaskill/Love+and+civilization.mp3'
    }
];

module.exports = audioData;
